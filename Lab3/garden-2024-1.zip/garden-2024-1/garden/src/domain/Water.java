package domain;

/**
 * Clase Water para dibujar cuadrados azules en el garden
 * 
 * @author Sofia Gil, Santiago Gualdron 
 * @version 1.0
 */
public final class Water  implements Thing{
    public void act(){
    }
}
