package test;
import domain.Sand;
import java.awt.Color;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * The test class SandTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SandTest
{
    @Test
    public void shouldMove() {}
}
