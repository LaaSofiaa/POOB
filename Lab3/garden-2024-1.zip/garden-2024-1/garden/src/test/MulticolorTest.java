package test;
import domain.Multicolor;
import domain.Garden;
import domain.Tree;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class MulticolorTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class MulticolorTest
{
    @Test
    public void shouldMove() {}
}
